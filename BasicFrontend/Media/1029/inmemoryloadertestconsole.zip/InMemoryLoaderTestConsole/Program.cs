﻿using System;
using System.Linq;
using InMemoryLoader;
using InMemoryLoaderBase;
using InMemoryLoaderCommon;
using log4net;

namespace InMemoryLoaderTestConsole
{
	/// <summary>
	/// Main class. Einfacher dummy der die Funktionsweise von PowerUpLoader anhand eines einfachen Beispiels erklärt
	/// </summary>
	class MainClass
	{
		/// <summary>
		/// log4net Instanz
		/// </summary>
		private static readonly ILog log = LogManager.GetLogger(typeof(MainClass));

		/// <summary>
		/// Pfad tur Test-Assembly
		/// </summary>
		private const string assembly = @"D:\github\InMemoryLoaderTestConsole\InMemoryLoaderTestComponent\bin\Debug\InMemoryLoaderTestComponent.dll";

		/// <summary>
		/// Pfad zum bin-Pfad der Anwendung
		/// </summary>
		private const string commonPath = @"D:\github\InMemoryLoaderTestConsole\InMemoryLoaderTestConsole\bin\Debug\";

		/// <summary>
		/// ComponentLoader Instanz-Variable
		/// </summary>
		private static ComponentLoader compLoader;

		/// <summary>
		/// CommonComponentLoader Instanz-Variable
		/// </summary>
		private static CommonComponentLoader commonCompLoader;

		/// <summary>
		/// The entry point of the program, where the program control starts and ends.
		/// </summary>
		/// <param name="args">The command-line arguments.</param>
		public static void Main(string[] args)
		{
			// log4net konfigurieren
			// TODO: Pfad zum Log-File muss angepasst werden!
			log4net.Config.XmlConfigurator.Configure();
			// ComponentLoader instanzieren
			compLoader = ComponentLoader.Instance;

			log.Info("Console-Programm and ComonentLoader init");

			// Methoden
			InitSimpleClass();
			InitCommonComponents();
			InitClassRegistry();

			Console.Read();
		}

		/// <summary>
		/// Inits the simple class.
		/// </summary>
		/// <param name="args">Arguments.</param>
		public static void InitSimpleClass()
		{
			// Instanz der DynamicClassSetup Klasse, wird benötigt um eine Klasse via InvokeMethod() in die Collection zu schreiben
			IDynamicClassSetup testComponent = new DynamicClassSetup();

			// Pfad zur Assembly
			testComponent.Assembly = assembly;
			// Klasse die registriert werden soll
			testComponent.Class = "MyClass";

			// Parameter Objekt - via AbstractPowerUpComponent.Key wird eine einfache Prüfung vorgenommen. Zwingend notwendig!
			object[] paramArgument = { AbstractPowerUpComponent.Key };
			// Das Objekt wird via InvokeMethod() registriert
			var init = compLoader.InvokeMethod(testComponent.Assembly, testComponent.Class, testComponent.InitMethod, paramArgument);
			// init = true falls erfolgreich
			log.InfoFormat("Assembly: {0}, Class: {1}, Is init: {2}", testComponent.Assembly, testComponent.Class, init);

			// Parameter-Objekt der Test-Klasse
			object[] paramMultiplyTwoInt = { 8, 8 };
			// Methode aus MyClass ausführen
			var result = compLoader.InvokeMethod(testComponent.Assembly, testComponent.Class, "MultiplyTwoInt", paramMultiplyTwoInt);
			// Resultat auswerten
			var stringResult = string.Format("MultiplyTwoInt: {0}", result);
			log.Info(stringResult);
		}

		/// <summary>
		/// Inits the common components.
		/// </summary>
		public static void InitCommonComponents()
		{
			// CommonComponentLoader instanzieren
			commonCompLoader = new CommonComponentLoader();
			// CommonComponents registrieren
			// TODO: Pfad muss angepasst werden
			commonCompLoader.InitCommonComponents(commonPath);

			// Existiert die Klasse "StringUtils"? Einnfaches Beispiel...
			var existsStringUtils = compLoader.ClassExists("StringUtils");
			log.InfoFormat("Class StringUtils exists: {0}", existsStringUtils);
		}

		/// <summary>
		/// Inits the class registry.
		/// </summary>
		public static void InitClassRegistry()
		{
			// Registry initialisieren
			compLoader.InitClassRegistry();

			// Ein Objekt aus der Registry ziehen
			var result = compLoader.ComponentRegistry.Where(str => str.Key.Class.Contains("CheckUtils")).SingleOrDefault();
			// Datentyp zuweisen
			var stringUtils = result.Value;

			// Ausführen uns auswerten
			Object[] args = { DateTime.Now.ToString() };
			Object Result = compLoader.InvokeMethod(stringUtils, "IsStringDate", args);

			log.InfoFormat("IsStringDate: {0}", Result);
		}
	}
}
