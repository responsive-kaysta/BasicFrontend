﻿//
// CheckUtilsTest.cs
//
// Author: responsive kaysta <me@responsive-kaysta.ch>
//
// Copyright (c) 2017 responsive kaysta
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

using log4net;
using Application;
using System;
using System.Linq;
using InMemoryLoaderBase;
using System.IO;

namespace TestHelper
{
    /// <summary>
    /// Test helper class.
    /// </summary>
    internal class TestHelperClass
    {
        /// <summary>
        /// The log.
        /// </summary>
        private static readonly ILog log = LogManager.GetLogger(typeof(TestHelperClass));
        /// <summary>
        /// The app base.
        /// </summary>
        private static readonly AppBase appBase = AppBase.Instance;

        /// <summary>
        /// The check utils test assembly.
        /// </summary>
        private readonly string checkUtilsTestAssembly = @Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CheckUtilsTest.dll");

        /// <summary>
        /// Gets or sets the check utils test class.
        /// </summary>
        /// <value>The check utils test class.</value>
        internal IDynamicClassInfo checkUtilsTestClass { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="TestHelper.TestHelperClass"/> class.
        /// </summary>
        internal TestHelperClass()
        {
            log.DebugFormat(appBase.instanceText, this.GetType().ToString());
        }

        /// <summary>
        /// Inits the check utils test.
        /// </summary>
        /// <returns><c>true</c>, if check utils test was inited, <c>false</c> otherwise.</returns>
        internal bool InitCheckUtilsTest()
        {
            // New instance of the setup class
            var component = new DynamicClassSetup();

            // The full path to the Assembly
            component.Assembly = checkUtilsTestAssembly;
            // The class we whant to use
            component.Class = "CheckUtilsTestClass";

            // Absolutely requiered! Without this key the instatiation whill fail.
            object[] paramArgument = { AbstractPowerUpComponent.Key };
            // Invoke th InitMethod
            var init = appBase.ComponentLoader.InvokeMethod(component.Assembly, component.Class, component.InitMethod, paramArgument);
            log.InfoFormat("Is CheckUtilsTestClass init: {0}", init);

            // Set the ClassRegistry, now the component is ready to use
            init = appBase.SetClassRegistry();
            checkUtilsTestClass = appBase.ComponentLoader.ComponentRegistry.SingleOrDefault(str => str.Key.Class.EndsWith("CheckUtilsTestClass")).Value;

            return init;
        }

        /// <summary>
        /// Runs the check utils test.
        /// </summary>
        /// <returns><c>true</c>, if check utils test was run, <c>false</c> otherwise.</returns>
        internal bool RunCheckUtilsTest()
        {
            object[] param = { true };
            var result = appBase.ComponentLoader.InvokeMethod(checkUtilsTestClass, "IsCheckUtilsTest", param);
            log.DebugFormat("IsCheckUtilsTest: {0}", result);

            return result;
        }

    }

}