﻿//
// CheckUtilsTestClass.Base.cs
//
// Author: responsive kaysta <me@responsive-kaysta.ch>
//
// Copyright (c) 2017 responsive kaysta
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

using System;
using System.Linq;
using log4net;
using InMemoryLoader;
using InMemoryLoaderBase;

namespace CheckUtilsTest
{
    /// <summary>
    /// Check utils test class.
    /// </summary>
    public partial class CheckUtilsTestClass : AbstractPowerUpComponent
    {
        /// <summary>
        /// The log.
        /// </summary>
        private static readonly ILog log = LogManager.GetLogger(typeof(CheckUtilsTestClass));
        /// <summary>
        /// The is byte.
        /// </summary>
        private static byte[] isByte = new byte[isInt];
        /// <summary>
        /// The is date.
        /// </summary>
        private static DateTime isDate = DateTime.Now;
        /// <summary>
        /// The is string.
        /// </summary>
        private const string isString = "Some String";
        /// <summary>
        /// The is decimal.
        /// </summary>
        private const Decimal isDecimal = 3.12m;
        /// <summary>
        /// The is double.
        /// </summary>
        private const Double isDouble = 3.12;
        /// <summary>
        /// The is float.
        /// </summary>
        private const float isFloat = 1.32f;
        /// <summary>
        /// The is string float.
        /// </summary>
        private const string isStringFloat = "5.687";
        /// <summary>
        /// The is int.
        /// </summary>
        private const long isLong = 12345678;
        /// <summary>
        /// The is string int.
        /// </summary>
        private const string isStringLong = "521345678";
        /// <summary>
        /// The is string URL.
        /// </summary>
        private const string isStringUrl = "http://www.google.ch/";
        /// <summary>
        /// The is string no URL.
        /// </summary>
        private const string isStringNoUrl = "Some String";
        /// <summary>
        /// The is int.
        /// </summary>
        private const int isInt = 123;
        /// <summary>
        /// The is string int.
        /// </summary>
        private const string isStringInt = "521";

        /// <summary>
        /// Gets or sets the component loader.
        /// </summary>
        /// <value>The component loader.</value>
        private static ComponentLoader ComponentLoader { get; set; }

        /// <summary>
        /// Gets the check utils.
        /// </summary>
        /// <value>The check utils.</value>
        private static IDynamicClassInfo CheckUtils
        {
            get
            {
                return ComponentLoader.ComponentRegistry.SingleOrDefault(str => str.Key.Class.EndsWith("CheckUtils")).Value;
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CheckUtilsTest.CheckUtilsTestClass"/> class.
        /// </summary>
        public CheckUtilsTestClass()
        {
            log.DebugFormat("Create a new instance of Type: {0}", this.GetType().ToString());
            ComponentLoader = ComponentLoader.Instance;
        }

        /// <summary>
        /// Determines whether this instance is check utils test the specified logVerbose.
        /// </summary>
        /// <returns><c>true</c> if this instance is check utils test the specified logVerbose; otherwise, <c>false</c>.</returns>
        /// <param name="logVerbose">If set to <c>true</c> log verbose.</param>
        public bool IsCheckUtilsTest(bool logVerbose)
        {
            bool isCheckUtilsTest = false;

            isCheckUtilsTest = IsStringIntTest1();
            isCheckUtilsTest = IsStringIntTest2();
            isCheckUtilsTest = IsStringIntTest3();
            isCheckUtilsTest = IsStringIntTest4();

            return isCheckUtilsTest;
        }

    }

}