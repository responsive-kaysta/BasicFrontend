﻿//
// CheckUtilsTestClass.Int.cs
//
// Author: responsive kaysta <me@responsive-kaysta.ch>
//
// Copyright (c) 2017 responsive kaysta
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

using System;
using InMemoryLoaderBase;
using System.Globalization;

namespace CheckUtilsTest
{
    /// <summary>
    /// Check utils test class.
    /// </summary>
    public partial class CheckUtilsTestClass : AbstractPowerUpComponent
    {
        /// <summary>
        /// Determines if is string int test1.
        /// </summary>
        /// <returns><c>true</c> if is string int test1; otherwise, <c>false</c>.</returns>
        private static bool IsStringIntTest1()
        {
            try
            {
                object[] paramArg = { isInt };
                var result = ComponentLoader.InvokeMethod(CheckUtils, "IsStringInt", paramArg);
                log.DebugFormat("IsStringIntTest1 (true) = {0}", result);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Determines if is string int test2.
        /// </summary>
        /// <returns><c>true</c> if is string int test2; otherwise, <c>false</c>.</returns>
        private static bool IsStringIntTest2()
        {
            try
            {
                object[] paramArg = { isStringInt };
                var result = ComponentLoader.InvokeMethod(CheckUtils, "IsStringInt", paramArg);
                log.DebugFormat("IsStringIntTest2 (true) = {0}", result);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Determines if is string int test3.
        /// </summary>
        /// <returns><c>true</c> if is string int test3; otherwise, <c>false</c>.</returns>
        private static bool IsStringIntTest3()
        {
            try
            {
                object[] paramArg = { isStringInt, CultureInfo.CurrentCulture };
                var result = ComponentLoader.InvokeMethod(CheckUtils, "IsStringInt", paramArg);
                log.DebugFormat("IsStringIntTest3 (true) = {0}", result);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Determines if is string int test4.
        /// </summary>
        /// <returns><c>true</c> if is string int test4; otherwise, <c>false</c>.</returns>
        private static bool IsStringIntTest4()
        {
            try
            {
                object[] paramArg = { isString, CultureInfo.CurrentCulture };
                var result = ComponentLoader.InvokeMethod(CheckUtils, "IsStringInt", paramArg);
                log.DebugFormat("IsStringIntTest4 (false) = {0}", result);
                return result == false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


    }

}